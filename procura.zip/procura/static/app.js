"use strict";

const messagesEl = document.getElementById("messages");
const formEl = document.getElementById("composer");
const inputEl = document.getElementById("input");
const sendBtn = document.getElementById("send-btn");
const resetBtn = document.getElementById("reset-btn");
const statusDot = document.getElementById("status-dot");

const CHART_COLORS = [
  "#3ecf8e", "#4aa3df", "#f0a07a", "#b98ee6",
  "#e6c84a", "#5fd0c4", "#e67ea0", "#7a9be6",
];

// --- helpers ---------------------------------------------------------------
function escapeHtml(text) {
  const div = document.createElement("div");
  div.textContent = text == null ? "" : String(text);
  return div.innerHTML;
}

function renderText(text) {
  // Plain text with line breaks preserved; no raw HTML from the model.
  return escapeHtml(text).replace(/\n/g, "<br>");
}

function scrollToBottom() {
  messagesEl.scrollTop = messagesEl.scrollHeight;
}

function addMessage(role, htmlContent, opts = {}) {
  const wrap = document.createElement("div");
  wrap.className = `message ${role}`;
  const bubble = document.createElement("div");
  bubble.className = "bubble" + (opts.error ? " error" : "");
  bubble.innerHTML = htmlContent;
  wrap.appendChild(bubble);
  messagesEl.appendChild(wrap);
  scrollToBottom();
  return bubble;
}

function showTyping() {
  const wrap = document.createElement("div");
  wrap.className = "message assistant";
  wrap.dataset.typing = "1";
  wrap.innerHTML =
    '<div class="bubble"><span class="typing"><span></span><span></span><span></span></span></div>';
  messagesEl.appendChild(wrap);
  scrollToBottom();
  return wrap;
}

// --- rendering of a data answer -------------------------------------------
function buildTable(table) {
  if (!table || !table.columns || !table.columns.length) return "";
  const head = table.columns.map((c) => `<th>${escapeHtml(c)}</th>`).join("");
  const body = table.rows
    .map(
      (row) =>
        "<tr>" +
        table.columns
          .map((c) => `<td>${escapeHtml(row[c])}</td>`)
          .join("") +
        "</tr>"
    )
    .join("");
  return `
    <details class="data">
      <summary>Data (${table.rows.length} row${table.rows.length === 1 ? "" : "s"} shown)</summary>
      <div class="table-scroll"><table><thead><tr>${head}</tr></thead><tbody>${body}</tbody></table></div>
    </details>`;
}

function renderChart(canvas, chart) {
  const isPie = chart.type === "pie" || chart.type === "doughnut";
  const datasets = chart.datasets.map((ds, i) => {
    if (isPie) {
      return {
        label: ds.label,
        data: ds.data,
        backgroundColor: chart.labels.map(
          (_, idx) => CHART_COLORS[idx % CHART_COLORS.length]
        ),
        borderColor: "#161d23",
        borderWidth: 2,
      };
    }
    const color = CHART_COLORS[i % CHART_COLORS.length];
    return {
      label: ds.label,
      data: ds.data,
      backgroundColor: chart.type === "line" ? "transparent" : color,
      borderColor: color,
      borderWidth: 2,
      tension: 0.25,
      pointRadius: 3,
      fill: false,
    };
  });

  const showLegend = isPie || chart.datasets.length > 1;

  // eslint-disable-next-line no-undef
  new Chart(canvas.getContext("2d"), {
    type: chart.type,
    data: { labels: chart.labels, datasets },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: {
          display: showLegend,
          labels: { color: "#8fa0ad", boxWidth: 12 },
        },
      },
      scales: isPie
        ? {}
        : {
            x: { ticks: { color: "#8fa0ad" }, grid: { color: "#2a353f" } },
            y: { ticks: { color: "#8fa0ad" }, grid: { color: "#2a353f" } },
          },
    },
  });
}

function renderAssistantData(data) {
  const bubble = addMessage("assistant", `<p>${renderText(data.reply)}</p>`);

  if (data.chart) {
    const chartWrap = document.createElement("div");
    chartWrap.className = "chart-wrap";
    if (data.chart.title) {
      const t = document.createElement("p");
      t.className = "chart-title";
      t.textContent = data.chart.title;
      chartWrap.appendChild(t);
    }
    const box = document.createElement("div");
    box.className = "chart-canvas-box";
    const canvas = document.createElement("canvas");
    box.appendChild(canvas);
    chartWrap.appendChild(box);
    bubble.appendChild(chartWrap);
    try {
      renderChart(canvas, data.chart);
    } catch (err) {
      chartWrap.remove();
      console.error("Chart render failed:", err);
    }
  }

  if (data.table && data.table.rows && data.table.rows.length) {
    bubble.insertAdjacentHTML("beforeend", buildTable(data.table));
  }

  if (data.truncated) {
    bubble.insertAdjacentHTML(
      "beforeend",
      `<p class="muted">Showing the first ${data.table.rows.length} of more rows.</p>`
    );
  }

  if (data.sql) {
    bubble.insertAdjacentHTML(
      "beforeend",
      `<details class="sql"><summary>View SQL</summary><pre class="sql">${escapeHtml(
        data.sql
      )}</pre></details>`
    );
  }
  scrollToBottom();
}

// --- network ---------------------------------------------------------------
async function sendMessage(message) {
  addMessage("user", `<p>${renderText(message)}</p>`);
  const typingEl = showTyping();
  sendBtn.disabled = true;

  try {
    const res = await fetch("/api/chat", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ message }),
    });
    const data = await res.json();
    typingEl.remove();

    if (data.type === "data") {
      renderAssistantData(data);
    } else if (data.type === "error") {
      addMessage("assistant", `<p>${renderText(data.reply)}</p>`, { error: true });
    } else {
      addMessage("assistant", `<p>${renderText(data.reply || data.error)}</p>`);
    }
  } catch (err) {
    typingEl.remove();
    addMessage(
      "assistant",
      "<p>Network error — I couldn't reach the server. Please try again.</p>",
      { error: true }
    );
    console.error(err);
  } finally {
    sendBtn.disabled = false;
    inputEl.focus();
  }
}

// --- events ----------------------------------------------------------------
function autoGrow() {
  inputEl.style.height = "auto";
  inputEl.style.height = Math.min(inputEl.scrollHeight, 160) + "px";
}

inputEl.addEventListener("input", autoGrow);

inputEl.addEventListener("keydown", (e) => {
  if (e.key === "Enter" && !e.shiftKey) {
    e.preventDefault();
    formEl.requestSubmit();
  }
});

formEl.addEventListener("submit", (e) => {
  e.preventDefault();
  const message = inputEl.value.trim();
  if (!message) return;
  inputEl.value = "";
  autoGrow();
  sendMessage(message);
});

resetBtn.addEventListener("click", async () => {
  try {
    await fetch("/api/reset", { method: "POST" });
  } catch (err) {
    console.error(err);
  }
  messagesEl.querySelectorAll(".message").forEach((m, i) => {
    if (i > 0) m.remove(); // keep the welcome message
  });
  inputEl.focus();
});

// --- health check ----------------------------------------------------------
(async function checkHealth() {
  try {
    const res = await fetch("/api/health");
    const data = await res.json();
    const up = data.database === "up";
    statusDot.classList.add(up ? "up" : "down");
    statusDot.title = up
      ? `Database connected · ${data.model}`
      : `Database ${data.database}`;
  } catch (err) {
    statusDot.classList.add("down");
    statusDot.title = "Server unreachable";
  }
})();

inputEl.focus();
