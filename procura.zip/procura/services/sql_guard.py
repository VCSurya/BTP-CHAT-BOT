"""Read-only SQL guard.

This is the security backstop for the natural-language-to-SQL pipeline. The
LLM is *asked* to produce read-only queries, but we never trust that. Every
query passes through here before it touches the database.

Strategy:
  1. Strip out string literals and quoted identifiers so they cannot hide
     forbidden keywords or extra statements (e.g. a column literally named
     "UPDATE" or a value like 'a; drop ...').
  2. Strip comments from that scrubbed copy.
  3. On the scrubbed copy, require the statement to start with SELECT or WITH,
     reject multiple statements, and reject any data-modifying keyword.
  4. Execute the *original* statement (HANA tolerates comments fine).
"""
import re

# Data-modifying / dangerous keywords. Deliberately excludes things that are
# also legitimate SELECT functions in HANA (e.g. REPLACE, SET is not a function
# but is handled by the SELECT-prefix rule).
_FORBIDDEN = re.compile(
    r"\b("
    r"INSERT|UPDATE|DELETE|DROP|ALTER|CREATE|TRUNCATE|MERGE|UPSERT|"
    r"GRANT|REVOKE|CALL|EXEC|EXECUTE|COMMIT|ROLLBACK|IMPORT|EXPORT|"
    r"REORG|UNLOAD|LOAD|RENAME|COMMENT"
    r")\b",
    re.IGNORECASE,
)

_STARTS_OK = re.compile(r"^\s*\(*\s*(SELECT|WITH)\b", re.IGNORECASE)


class SqlValidationError(Exception):
    """Raised when a generated query is not a safe, read-only single SELECT."""


def _scrub(sql: str) -> str:
    """Replace string literals and double-quoted identifiers with empty markers
    so the structural scan only sees real SQL syntax."""
    sql = re.sub(r"'(?:[^']|'')*'", "''", sql)   # 'string literals'
    sql = re.sub(r'"(?:[^"]|"")*"', '""', sql)    # "quoted identifiers"
    return sql


def _strip_comments(sql: str) -> str:
    sql = re.sub(r"/\*.*?\*/", " ", sql, flags=re.S)
    sql = re.sub(r"--[^\n]*", " ", sql)
    return sql


def validate_select(sql: str, max_chars: int = 6000) -> str:
    """Validate and return the cleaned SQL statement, or raise
    SqlValidationError. The returned string is safe to execute."""
    if not sql or not sql.strip():
        raise SqlValidationError("The query was empty.")

    original = sql.strip()
    if len(original) > max_chars:
        raise SqlValidationError("The query is unusually long and was rejected.")

    # Statement we will actually run: strip a single trailing semicolon.
    runnable = original.rstrip()
    if runnable.endswith(";"):
        runnable = runnable[:-1].rstrip()

    # Build the scan copy: scrub literals first, then strip comments.
    scan = _strip_comments(_scrub(runnable))

    if ";" in scan:
        raise SqlValidationError("Only a single statement is allowed.")

    if not _STARTS_OK.match(scan):
        raise SqlValidationError("Only read-only SELECT queries are allowed.")

    forbidden = _FORBIDDEN.search(scan)
    if forbidden:
        raise SqlValidationError(
            f"The query contains a disallowed operation: {forbidden.group(1).upper()}."
        )

    return runnable
