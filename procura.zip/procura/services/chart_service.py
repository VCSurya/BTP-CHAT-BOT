"""Turn a query result + the model's column mapping into a Chart.js spec.

The chart data is built in Python directly from the real returned rows, so the
numbers shown can never be hallucinated. The LLM only chooses the chart type
and which columns map to labels/values.
"""

_CHART_TYPES = {"bar", "line", "pie", "doughnut"}


def _to_number(value):
    if value is None:
        return None
    if isinstance(value, bool):
        return None
    if isinstance(value, (int, float)):
        return value
    try:
        return float(str(value).replace(",", ""))
    except (ValueError, TypeError):
        return None


def _to_label(value):
    if value is None:
        return ""
    return str(value)


def build_chart(result: dict, viz: dict, max_points: int = 30):
    """Return a Chart.js-ready dict, or None when a chart would not help."""
    if not viz:
        return None

    rows = result.get("rows") or []
    columns = result.get("columns") or []
    if not rows:
        return None

    chart_type = (viz.get("type") or "none").lower()
    if chart_type not in _CHART_TYPES:
        return None

    label_col = viz.get("label_column")
    value_cols = [c for c in (viz.get("value_columns") or []) if c in columns]
    if not label_col or label_col not in columns or not value_cols:
        return None

    # Pie/doughnut only make sense with a single series.
    if chart_type in ("pie", "doughnut"):
        value_cols = value_cols[:1]

    sample = rows[:max_points]
    labels = [_to_label(r.get(label_col)) for r in sample]

    datasets = []
    for col in value_cols:
        series = [_to_number(r.get(col)) for r in sample]
        if all(v is None for v in series):
            continue
        datasets.append({"label": col, "data": series})

    if not datasets:
        return None

    return {
        "type": chart_type,
        "title": (viz.get("title") or "").strip(),
        "labels": labels,
        "datasets": datasets,
        "truncated_points": len(rows) > len(sample),
    }
